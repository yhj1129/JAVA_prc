package src.ch02;

public interface Add {

    int add(int x, int y);
}
