package src.ch03;

@FunctionalInterface
public interface MyNumber {
    int getMax(int num1, int num2);
}
