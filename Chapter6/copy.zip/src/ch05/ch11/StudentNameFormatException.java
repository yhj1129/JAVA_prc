package src.ch05.ch11;

public class StudentNameFormatException extends IllegalArgumentException{

    public StudentNameFormatException(String message){
        super(message);
    }
}
