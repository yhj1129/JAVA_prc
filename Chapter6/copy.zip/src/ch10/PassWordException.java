package src.ch10;

public class PassWordException extends Exception{
    public PassWordException(String message){
        super(message);
    }
}
