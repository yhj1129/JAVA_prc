package src.ch16;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCopyTest {
    public static void main(String[] args) {
        long millisecond = 0;

        try(FileInputStream fis = new FileInputStream("a.zip");
            FileOutputStream fos = new FileOutputStream("copy.zip")) {

            millisecond = System.currentTimeMillis();//수행한 시간 계산
            int i;
            while ((i = fis.read()) != -1){ //a.zip을 읽어서
                fos.write(i); // copy.zip에 write
            }
            millisecond = System.currentTimeMillis() - millisecond;
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(millisecond + " 소요되었습니다");
    }
}
